-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2021 at 05:48 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `keells`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `message` varchar(200) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `name`, `message`, `type`) VALUES
(1, 'roshan', 'hi famer', '1'),
(2, 'roshan', 'thank you', '0'),
(3, 'ishini', 'hi', '0'),
(4, 'roshan', 'hello', '1'),
(5, 'hiruni', 'hello', '1'),
(6, 'hiruni', '123', '1'),
(7, 'hiruni', '123', '1');

-- --------------------------------------------------------

--
-- Table structure for table `homechart`
--

CREATE TABLE `homechart` (
  `category` varchar(200) NOT NULL,
  `quantity` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homechart`
--

INSERT INTO `homechart` (`category`, `quantity`) VALUES
('Tomato (KG)', 800),
('Potato (KG)', 800),
('Onion (KG)', 1000),
('Radish (KG)', 800),
('Pumpkin (KG)', 1000),
('Beetroot (KG)', 800),
('Leek (KG)', 600),
('Carrot (KG)', 500),
('Garlic (KG)', 500),
('Eggplant (KG)', 600),
('Cabbage (KG)', 500),
('Eggs', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `homechart2`
--

CREATE TABLE `homechart2` (
  `category` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homechart2`
--

INSERT INTO `homechart2` (`category`, `quantity`) VALUES
('Tomato (KG)', 800),
('Potato (KG)', 1000),
('Onion (KG)', 900),
('Radish (KG)', 800),
('Pumpkin (KG)', 800),
('Beetroot (KG)', 700),
('Leek (KG)', 500),
('Carrot (KG)', 1000),
('Garlic (KG)', 800),
('Eggplant (KG)', 800),
('Cabbage (KG)', 500),
('Eggs', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `homechart3`
--

CREATE TABLE `homechart3` (
  `category` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homechart3`
--

INSERT INTO `homechart3` (`category`, `quantity`) VALUES
('Banana (KG)', 500),
('Mango ', 1000),
('Pineapple', 800),
('Woodapple', 700),
('Watermelon', 800),
('Avacado', 500),
('Dragon Fruit', 600),
('Pomegranate', 600);

-- --------------------------------------------------------

--
-- Table structure for table `homechart4`
--

CREATE TABLE `homechart4` (
  `category` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homechart4`
--

INSERT INTO `homechart4` (`category`, `quantity`) VALUES
('Banana (KG)', 600),
('Mango', 800),
('Pineapple', 600),
('Wood dapple', 700),
('Watermelon', 700),
('Avocado', 700),
('Dragon fruit', 700),
('Pomegranate', 800);

-- --------------------------------------------------------

--
-- Table structure for table `keells_admin`
--

CREATE TABLE `keells_admin` (
  `id` int(11) NOT NULL,
  `userName` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `keells_admin`
--

INSERT INTO `keells_admin` (`id`, `userName`, `password`, `type`) VALUES
(1, 'roshan', '1998', 'DOA'),
(2, 'kavindu', '1999', 'keells');

-- --------------------------------------------------------

--
-- Table structure for table `oder`
--

CREATE TABLE `oder` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `category` varchar(45) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` blob NOT NULL,
  `lat` varchar(100) NOT NULL,
  `lng` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oder`
--

INSERT INTO `oder` (`id`, `name`, `phone`, `category`, `quantity`, `image`, `lat`, `lng`, `status`, `type`) VALUES
(19, 'Roshan', '0769252297', 'Tomato ', 150, 0x313531393835363130393137382e6a706567, '6.796016502635264', '80.46815179821782', 1, 'Vegetables'),
(22, 'Ayomal', '0714359564', 'Tomato ', 100, 0x646f776e6c6f61642e6a666966, '6.991938775134917', '81.05188983745953', 0, 'Vegetables'),
(23, 'Roshan', '0769252297', 'Eggs ', 700, 0x612d6261736b65742d6f662d65676773, '6.94616394603746', '80.7813479804688', 0, 'Vegetables'),
(24, 'Ishini', '0752492322', 'Potato ', 250, 0x53747564792d506f7461746f2d70726f7465696e2d612d77696e6e65722d666f722d776f6d656e5f7772626d5f6c61726765, '6.0476731888783615', '80.53576463527143', 0, 'Vegetables'),
(25, 'Hiruni', '0713882429', 'Pumpkin ', 100, 0x4672656e63684d61726b657450756d706b696e7342, '7.315722498450609', '80.67493511549094', 0, 'Vegetables'),
(26, 'Ewantha ', '0713525929', 'Potato ', 100, 0x53747564792d506f7461746f2d70726f7465696e2d612d77696e6e65722d666f722d776f6d656e5f7772626d5f6c61726765, '8.328363839231432', '80.3912641958334', 0, 'Vegetables'),
(27, 'Kamal', '0713882429', 'Onion ', 150, 0x35, '7.889618581157906', '80.61065970991773', 0, 'Vegetables'),
(28, 'Sunil', '0713882429', 'Mango ', 500, 0x6d616e676f, '7.926775242024727', '81.01548873481083', 0, 'Fruits'),
(29, 'Namal', '0752492322', 'Banana ', 150, 0x62616e616e612d6861636b2d6b622d6d61696e2d3230313032375f3663633238313262313233626361653136306238373765303236663235643332, '8.107807175857623', '80.29348634716801', 0, 'Fruits'),
(30, 'Hiruni', '0714359564', 'Radish ', 200, 0x726164697368, '6.9407110689653795', '80.77310823437504', 1, 'Vegetables'),
(31, 'Ewantha ', '0714359564', 'Carrot ', 100, 0x646f776e6c6f6164202831292e6a666966, '8.437715696346526', '80.39945962588081', 0, 'Vegetables'),
(32, 'Roshan', '0769252297', 'Watermelon ', 200, 0x696d616765732e6a666966, '6.959795862006757', '80.76761507031254', 0, 'Vegetables'),
(34, 'Ayomal', '0714359564', 'Tomato ', 200, 0x646f776e6c6f61642e6a666966, '6.908339743681876', '81.09951826725991', 0, 'Vegetables'),
(35, 'Sunil', '0752492322', 'Mango ', 700, 0x6d616e676f, '7.94564667713284', '80.92691682812504', 0, 'Fruits'),
(36, 'Hiruni', '0714359564', 'Carrot ', 250, 0x646f776e6c6f6164202831292e6a666966, '7.3159353411917625', '80.65312213839003', 0, 'Vegetables'),
(37, 'Ewantha ', '0752492322', 'Banana ', 250, 0x62616e616e612d6861636b2d6b622d6d61696e2d3230313032375f3663633238313262313233626361653136306238373765303236663235643332, '6.850994379652259', '80.67360575972175', 0, 'Fruits'),
(38, 'Ishini', '0713882429', 'Dragon Fruits ', 300, 0x646f776e6c6f6164202832292e6a666966, '6.087953912864422', '80.69071077343754', 0, 'Fruits');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `userName` varchar(45) NOT NULL,
  `nicNumber` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `userName`, `nicNumber`, `password`) VALUES
(1, 'kavindu', '3435435', '456577'),
(2, 'sky', '4546565', '565657'),
(5, 'roshan', '980236489v', '1998'),
(7, 'hiruni', '1234', '1997'),
(8, 'ishini', '991234', '1999'),
(9, 'ewantha', '991234', '1999'),
(10, 'ayomal', '991234', '1999'),
(11, 'kamal', '991234', '1998'),
(12, 'sunil', '991234', '1999'),
(13, 'namal', '991234', '1999');

-- --------------------------------------------------------

--
-- Table structure for table `wasted_fruits`
--

CREATE TABLE `wasted_fruits` (
  `category` varchar(200) NOT NULL,
  `quantity` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wasted_fruits`
--

INSERT INTO `wasted_fruits` (`category`, `quantity`) VALUES
('Banana(KG)', 120),
('Mango', 250),
('Watermelon', 236),
('Avacado', 176),
('Woodapple', 121);

-- --------------------------------------------------------

--
-- Table structure for table `wasted_vegetables`
--

CREATE TABLE `wasted_vegetables` (
  `category` varchar(200) NOT NULL,
  `quantity` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wasted_vegetables`
--

INSERT INTO `wasted_vegetables` (`category`, `quantity`) VALUES
('Tomato(KG)', 50),
('Potato(KG)', 70),
('Onion(KG)', 100),
('Radish(KG)', 110),
('Pumpkin(KG)', 250),
('Carrot(KG)', 150);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keells_admin`
--
ALTER TABLE `keells_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oder`
--
ALTER TABLE `oder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `keells_admin`
--
ALTER TABLE `keells_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oder`
--
ALTER TABLE `oder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
