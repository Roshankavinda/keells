-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2021 at 08:56 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `keells`
--

-- --------------------------------------------------------

--
-- Table structure for table `homechart`
--

CREATE TABLE `homechart` (
  `category` varchar(200) NOT NULL,
  `quantity` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homechart`
--

INSERT INTO `homechart` (`category`, `quantity`) VALUES
('Tomato (KG)', 800),
('Potato (KG)', 800),
('Onion (KG)', 1000),
('Radish (KG)', 800),
('Pumpkin (KG)', 1000),
('Beetroot (KG)', 800),
('Leek (KG)', 600),
('Carrot (KG)', 500),
('Garlic (KG)', 500),
('Eggplant (KG)', 600),
('Cabbage (KG)', 500),
('Eggs', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `homechart2`
--

CREATE TABLE `homechart2` (
  `category` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homechart2`
--

INSERT INTO `homechart2` (`category`, `quantity`) VALUES
('Tomato (KG)', 800),
('Potato (KG)', 1000),
('Onion (KG)', 900),
('Radish (KG)', 800),
('Pumpkin (KG)', 800),
('Beetroot (KG)', 700),
('Leek (KG)', 500),
('Carrot (KG)', 1000),
('Garlic (KG)', 800),
('Eggplant (KG)', 800),
('Cabbage (KG)', 500),
('Eggs', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `homechart3`
--

CREATE TABLE `homechart3` (
  `category` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homechart3`
--

INSERT INTO `homechart3` (`category`, `quantity`) VALUES
('Banana (KG)', 500),
('Mango ', 1000),
('Pineapple', 800),
('Woodapple', 700),
('Watermelon', 800),
('Avacado', 500),
('Dragon Fruit', 600),
('Pomegranate', 600);

-- --------------------------------------------------------

--
-- Table structure for table `homechart4`
--

CREATE TABLE `homechart4` (
  `category` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homechart4`
--

INSERT INTO `homechart4` (`category`, `quantity`) VALUES
('Banana (KG)', 600),
('Mango', 800),
('Pineapple', 600),
('Wood dapple', 700),
('Watermelon', 700),
('Avocado', 700),
('Dragon fruit', 700),
('Pomegranate', 800);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `userName` varchar(45) NOT NULL,
  `nicNumber` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `userName`, `nicNumber`, `password`) VALUES
(1, '', '3435435', '456577'),
(2, '', '4546565', '565657'),
(3, 'uwiewe', '33435435', '454546'),
(5, 'roshan', '980236489v', '1998');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
